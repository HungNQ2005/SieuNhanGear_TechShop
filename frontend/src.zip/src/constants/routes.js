export const ROUTES = {
  //Navigate to front-end
  ROOT: "/",
  HOME: "/home",
  SHOWROOM: "/showroom",
  PRODUCT_PAGE: "/product/:id",
  CART: "/cart",
  ORDER_MANAGEMENT: "/admin/orders",
  CHECKOUT: "/checkout",
  ORDER: "/order",
};
