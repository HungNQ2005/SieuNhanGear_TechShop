import React, { useEffect, useState } from "react";
import { Modal, View, Text, TextInput, TouchableOpacity } from "react-native";

import { useLocalization } from "../../../../../providers/LocalizationProvider";

import {
  TEXT_VOUCHER_MODAL_TITLE,
  TEXT_VOUCHER_MODAL_CODE,
  TEXT_VOUCHER_MODAL_TYPE,
  TEXT_VOUCHER_MODAL_VALUE,
  TEXT_VOUCHER_MODAL_EXPIRY,
  TEXT_VOUCHER_MODAL_CANCEL,
  TEXT_VOUCHER_MODAL_SAVE,
} from "../../../../../constants/i18nKeys";

export default function VoucherModal({
  visible,
  voucher,
  saving,
  onClose,
  onConfirm,
}) {
  const { t } = useLocalization();

  const [code, setCode] = useState("");
  const [discountType, setDiscountType] = useState("percent");
  const [discountValue, setDiscountValue] = useState("");
  const [expiryDate, setExpiryDate] = useState("");

  useEffect(() => {
    if (voucher) {
      setCode(voucher.code || "");
      setDiscountType(voucher.discountType || "percent");
      setDiscountValue(
        voucher.discountValue != null ? String(voucher.discountValue) : "",
      );
      setExpiryDate(voucher.expiryDate || "");
    } else {
      setCode("");
      setDiscountType("percent");
      setDiscountValue("");
      setExpiryDate("");
    }
  }, [voucher, visible]);

  const isValid =
    code.trim() !== "" &&
    discountValue.trim() !== "" &&
    expiryDate.trim() !== "" &&
    Number(discountValue) > 0;

  const handleSave = () => {
    if (!isValid) return;

    onConfirm({
      ...(voucher || {}),
      code: code.trim(),
      discountType,
      discountValue: Number(discountValue),
      expiryDate,
    });
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          backgroundColor: "rgba(15,23,42,0.45)",
          justifyContent: "center",
          alignItems: "center",
          padding: 24,
        }}
      >
        <View
          style={{
            width: "100%",
            maxWidth: 500,
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            padding: 24,
          }}
        >
          <Text
            style={{
              fontSize: 22,
              fontWeight: "700",
              color: "#111827",
              marginBottom: 20,
            }}
          >
            {voucher?.id
              ? `Edit ${t(TEXT_VOUCHER_MODAL_TITLE)}`
              : `Create ${t(TEXT_VOUCHER_MODAL_TITLE)}`}
          </Text>

          {/* Voucher Code */}
          <Text
            style={{
              marginBottom: 6,
              color: "#6B7280",
              fontSize: 13,
            }}
          >
            {t(TEXT_VOUCHER_MODAL_CODE)}
          </Text>

          <TextInput
            value={code}
            onChangeText={setCode}
            placeholder="WELCOME10"
            style={{
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 8,
              paddingHorizontal: 12,
              height: 44,
              marginBottom: 16,
            }}
          />

          {/* Discount Type */}
          <Text
            style={{
              marginBottom: 6,
              color: "#6B7280",
              fontSize: 13,
            }}
          >
            {t(TEXT_VOUCHER_MODAL_TYPE)}
          </Text>

          <View
            style={{
              flexDirection: "row",
              marginBottom: 16,
            }}
          >
            <TouchableOpacity
              onPress={() => setDiscountType("percent")}
              style={{
                flex: 1,
                paddingVertical: 12,
                borderWidth: 1,
                borderColor: "#2563EB",
                backgroundColor:
                  discountType === "percent" ? "#2563EB" : "#FFFFFF",
                borderRadius: 8,
                marginRight: 8,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: discountType === "percent" ? "#FFFFFF" : "#2563EB",
                  fontWeight: "600",
                }}
              >
                Percentage (%)
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setDiscountType("fixed")}
              style={{
                flex: 1,
                paddingVertical: 12,
                borderWidth: 1,
                borderColor: "#2563EB",
                backgroundColor:
                  discountType === "fixed" ? "#2563EB" : "#FFFFFF",
                borderRadius: 8,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: discountType === "fixed" ? "#FFFFFF" : "#2563EB",
                  fontWeight: "600",
                }}
              >
                Fixed Amount
              </Text>
            </TouchableOpacity>
          </View>

          {/* Discount Value */}
          <Text
            style={{
              marginBottom: 6,
              color: "#6B7280",
              fontSize: 13,
            }}
          >
            {t(TEXT_VOUCHER_MODAL_VALUE)}
          </Text>

          <TextInput
            value={discountValue}
            onChangeText={setDiscountValue}
            keyboardType="numeric"
            placeholder="10"
            style={{
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 8,
              paddingHorizontal: 12,
              height: 44,
              marginBottom: 16,
            }}
          />

          {/* Expiry */}
          <Text
            style={{
              marginBottom: 6,
              color: "#6B7280",
              fontSize: 13,
            }}
          >
            {t(TEXT_VOUCHER_MODAL_EXPIRY)}
          </Text>

          <TextInput
            value={expiryDate}
            onChangeText={setExpiryDate}
            placeholder="YYYY-MM-DD"
            style={{
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 8,
              paddingHorizontal: 12,
              height: 44,
            }}
          />

          <View
            style={{
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: 28,
            }}
          >
            <TouchableOpacity
              onPress={onClose}
              style={{
                borderWidth: 1,
                borderColor: "#D1D5DB",
                borderRadius: 8,
                paddingHorizontal: 20,
                paddingVertical: 11,
                marginRight: 12,
              }}
            >
              <Text
                style={{
                  color: "#374151",
                  fontWeight: "600",
                }}
              >
                {t(TEXT_VOUCHER_MODAL_CANCEL)}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              disabled={!isValid || saving}
              onPress={handleSave}
              style={{
                backgroundColor: "#2563EB",
                borderRadius: 8,
                paddingHorizontal: 20,
                paddingVertical: 11,
                opacity: !isValid || saving ? 0.6 : 1,
              }}
            >
              <Text
                style={{
                  color: "#FFFFFF",
                  fontWeight: "700",
                }}
              >
                {saving ? "Saving..." : t(TEXT_VOUCHER_MODAL_SAVE)}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
