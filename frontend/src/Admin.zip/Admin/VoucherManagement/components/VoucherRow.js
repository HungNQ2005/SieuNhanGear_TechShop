import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
} from "react-native";

import { useLocalization } from "../../../../../providers/LocalizationProvider";

import {
  TEXT_EDIT,
  TEXT_DELETE,
} from "../../../../../constants/i18nKeys";

import VoucherStatusBadge from "./VoucherStatusBadge";

export default function VoucherRow({
  row = {},
  onEdit = () => {},
  onDelete = () => {},
}) {
  const { t } = useLocalization();

  let discountType = row.discountType || "-";
  let discountValue = "-";

  switch (row.discountType) {
    case "Percentage":
      discountValue =
        row.discountValue != null
          ? `${row.discountValue}%`
          : "-";
      break;

    case "Fixed Amount":
      discountValue =
        row.discountValue != null
          ? `$${row.discountValue}`
          : "-";
      break;

    case "Free Shipping":
      discountValue = "Free";
      break;

    default:
      discountValue =
        row.discountValue != null
          ? `${row.discountValue}`
          : "-";
      break;
  }

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        minHeight: 64,
        paddingHorizontal: 20,
        borderTopWidth: 1,
        borderColor: "#F3F4F6",
        backgroundColor: "#FFFFFF",
      }}
    >
      {/* Voucher Code */}
      <View style={{ flex: 2 }}>
        <Text
          style={{
            fontSize: 14,
            fontWeight: "700",
            color: "#111827",
          }}
        >
          {row.code || "-"}
        </Text>
      </View>

      {/* Discount Type */}
      <View style={{ flex: 2 }}>
        <Text
          style={{
            fontSize: 14,
            color: "#374151",
          }}
        >
          {discountType}
        </Text>
      </View>

      {/* Discount Value */}
      <View style={{ flex: 1.5 }}>
        <Text
          style={{
            fontSize: 14,
            color: "#374151",
          }}
        >
          {discountValue}
        </Text>
      </View>

      {/* Expiry Date */}
      <View style={{ flex: 2 }}>
        <Text
          style={{
            fontSize: 14,
            color: "#374151",
          }}
        >
          {row.expiryDate || "-"}
        </Text>
      </View>

      {/* Status */}
      <View
        style={{
          flex: 1.5,
          alignItems: "flex-start",
        }}
      >
        <VoucherStatusBadge
          status={row.status}
        />
      </View>

      {/* Actions */}
      <View
        style={{
          flex: 1.2,
          flexDirection: "row",
          justifyContent: "flex-end",
        }}
      >
        <TouchableOpacity
          onPress={() => onEdit(row)}
          style={{ marginRight: 14 }}
        >
          <Text
            style={{
              color: "#2563EB",
              fontWeight: "600",
            }}
          >
            {t(TEXT_EDIT)}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => onDelete(row)}
        >
          <Text
            style={{
              color: "#DC2626",
              fontWeight: "600",
            }}
          >
            {t(TEXT_DELETE)}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}