import React from "react";
import { View, Text, Image } from "react-native";

import styles from "../styles/OrderSummaryCard.style";

export default function OrderSummaryCard({ order }) {
  if (!order) return null;
  const subtotal =
    order.items?.reduce((sum, item) => sum + item.price * item.quantity, 0) ||
    0;

  const shipping = 0;

  const total = subtotal + shipping;
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Sản phẩm ({order.items?.length || 0})</Text>

      {order.items?.map((item) => (
        <View key={item.id} style={styles.product}>
          <Image
            source={{
              uri: item.image || "https://picsum.photos/100",
            }}
            style={styles.image}
          />

          <View style={styles.info}>
            <Text style={styles.brand}>{item.brand}</Text>

            <Text style={styles.name}>{item.name}</Text>

            <Text style={styles.spec}>{item.specs}</Text>

            <Text style={styles.qty}>x{item.quantity}</Text>
          </View>

          <Text style={styles.price}>{item.price?.toLocaleString()}đ</Text>
        </View>
      ))}

      <View style={styles.divider} />

      <View style={styles.row}>
        <Text style={styles.label}>Tạm tính</Text>

        <Text style={styles.value}>{subtotal.toLocaleString()}đ</Text>
      </View>

      <View style={styles.row}>
        <Text style={styles.label}>Phí vận chuyển</Text>

        <Text style={styles.free}>Miễn phí</Text>
      </View>

      <View style={styles.divider} />

      <View style={styles.row}>
        <Text style={styles.total}>Tổng cộng</Text>

        <Text style={styles.totalPrice}>{total.toLocaleString()}đ</Text>
      </View>
    </View>
  );
}
