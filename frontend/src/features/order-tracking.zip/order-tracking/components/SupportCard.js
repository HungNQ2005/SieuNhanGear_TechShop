import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
} from "react-native";

import styles from "../styles/SupportCard.style";

export default function SupportCard() {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>
        Cần hỗ trợ?
      </Text>

      <TouchableOpacity style={styles.item}>
        <Text>📞 Gọi Hotline</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.item}>
        <Text>⭐ Đánh giá đơn hàng</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.item}>
        <Text>🔄 Đổi trả hàng</Text>
      </TouchableOpacity>
    </View>
  );
}