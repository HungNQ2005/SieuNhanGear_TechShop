import React from "react";
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
} from "react-native";

import styles from "../styles/OrderTrackingHeader.style";

export default function OrderTrackingHeader({
  orderCode,
  setOrderCode,
  onSearch,
}) {
  return (
    <View style={styles.card}>
      <View style={styles.headingRow}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>LIVE</Text>
        </View>

        <Text style={styles.title}>Tra cứu đơn hàng</Text>
      </View>

      <Text style={styles.subtitle}>
        Nhập mã đơn để xem hành trình, trạng thái và thông tin giao hàng trong một giao diện gọn, rõ ràng.
      </Text>

      <View style={styles.searchRow}>
        <TextInput
          value={orderCode}
          onChangeText={setOrderCode}
          placeholder="#DH-20240528"
          placeholderTextColor="#94A3B8"
          style={styles.input}
        />

        <TouchableOpacity
          onPress={onSearch}
          activeOpacity={0.9}
          style={styles.button}
        >
          <Text style={styles.buttonText}>
            Tra cứu
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.helperText}>
        Mẹo: dùng mã bắt đầu bằng #DH để tìm nhanh hơn.
      </Text>
    </View>
  );
}