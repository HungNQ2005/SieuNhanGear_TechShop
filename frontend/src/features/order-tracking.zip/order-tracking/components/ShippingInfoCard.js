import React from "react";
import { View, Text } from "react-native";

import styles from "../styles/ShippingInfoCard.style";

export default function ShippingInfoCard({ order }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>
        Thông tin vận chuyển
      </Text>

      <View style={styles.row}>
        <View>
          <Text style={styles.label}>
            Đơn vị vận chuyển
          </Text>

          <Text style={styles.value}>
            {order.shippingCompany}
          </Text>
        </View>

        <View>
          <Text style={styles.label}>
            Mã vận đơn
          </Text>

          <Text style={styles.value}>
            {order.trackingCode}
          </Text>
        </View>
      </View>

      <View style={styles.row}>
        <View>
          <Text style={styles.label}>
            Địa chỉ nhận
          </Text>

          <Text style={styles.value}>
            {order.address}
          </Text>
        </View>

        <View>
          <Text style={styles.label}>
            Số điện thoại
          </Text>

          <Text style={styles.value}>
            {order.phone}
          </Text>
        </View>
      </View>
    </View>
  );
}