import React from "react";

import {
 View,
 Text,
} from "react-native";

import styles from "../styles/OrderTimelineCard.style";

export default function OrderTimelineCard({
 order,
}) {

 const timeline =
  order?.timeline || [];

 if (
  timeline.length === 0
 ) {
  return (
   <View
    style={styles.card}
   >
    <Text
     style={styles.title}
    >
      Hành trình đơn hàng
    </Text>

    <Text>
      Chưa có dữ liệu vận chuyển
    </Text>
   </View>
  );
 }

 return (
  <View style={styles.card}>

   <Text style={styles.title}>
    Hành trình đơn hàng
   </Text>

   {timeline.map(
    (
     item,
     index
    ) => (

    <View
     key={index}
     style={
      styles.timelineItem
     }
    >

     <View>

      <View
       style={
        styles.dot
       }
      />

      {index <
       timeline.length -
       1 && (
       <View
        style={
         styles.line
        }
       />
      )}

     </View>

     <View
      style={
       styles.box
      }
     >

      <Text
       style={
        styles.stepTitle
       }
      >
       {item?.title ||
        "Đang cập nhật"}
      </Text>

      <Text>
       {item?.description ||
        ""}
      </Text>

      <Text
       style={
        styles.time
       }
      >
       {item?.time ||
        ""}
      </Text>

     </View>

    </View>

   ))}
  </View>
 );
}