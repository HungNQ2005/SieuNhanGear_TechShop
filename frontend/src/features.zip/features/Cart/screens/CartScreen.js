import React from "react";
import { View, Text } from "react-native";
import { useCart } from "../../../store/CartContext";

export default function CartScreen() {
  const { items } = useCart();

  console.log("CartScreen render");
  console.log("Items:", items);
  const { items, increaseQuantity, decreaseQuantity, removeItem } = useCart();
  return (
    <View style={styles.left}>
      {items.map((item) => (
        <CartItem
          key={item.id}
          item={item}
          onIncrease={increaseQuantity}
          onDecrease={decreaseQuantity}
          onRemove={removeItem}
        />
      ))}

      <View style={styles.right}>
        <CartSummary />
      </View>
    </View>
  );
}
